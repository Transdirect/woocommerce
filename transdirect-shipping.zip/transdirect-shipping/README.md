Transdirect Shipping plugin for WooCommerce

Description: This plugin allows you to add Transdirect shipping in Woocommerce shipping options. This shipping option shows up rates from different couriers in Australia based from delivery and destination postcodes.

Requirement: WooCommerce plugin at least version 2.2.4

Setup: Under WooCommerce shipping settings, enable Transdirect Shipping and fill out authentication fields which come from Transdirect.
