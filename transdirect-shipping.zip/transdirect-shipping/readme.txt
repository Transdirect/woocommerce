=== Transdirect Shipping Plugin for Woocommerce ===
Contributors: transdirect, bywave
Tags: woocommerce, woo-commerce, ecommerce, e-commerce, commerce, wordpress ecommerce, quotes, transdirect, quick quotes, cart, checkout, configurable, shipping, tax
Requires at least: 3.8
Tested up to: 4.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Transdirect Shipping - Couriers, Freight & Shipping Services in Australia. Join Hundreds of Thousands of Australians that trust Transdirect with their freight requirements.

== Description ==

Transdirect Shipping is a Woocommerce plugin which allows you to add Transdirect shipping in Woocommerce shipping options. This shipping option shows up rates from different couriers in Australia based from delivery and destination postcodes.
